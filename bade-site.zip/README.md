# Ba&De davet salonu — demo

Ba&De için hazırlanan, Türkçe ve mobil uyumlu web sitesi demosu.

Bu depo yalnızca yayımlanmaya hazır statik dosyaları içerir. İşletmenin resmî sitesi veya rezervasyon sistemi değildir. Tüm HTML sayfalarında noindex, nofollow bulunur.

HTML, özel CSS ve vanilla JavaScript kullanılır; sunucu, veritabanı ve çalışma zamanı bağımlılığı gerekmez. GitHub Pages kaynağı: main dalı, / (root).

Fotoğraf kaynakları asset-sources.json dosyasında, font lisansları assets/ klasöründedir.
