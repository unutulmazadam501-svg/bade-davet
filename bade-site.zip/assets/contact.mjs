export const EVENT_TYPES = ['Nişan organizasyonu', 'Kına gecesi', 'Davet salonu'];

export function istanbulToday(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Istanbul', year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(now);
  const value = type => parts.find(p => p.type === type).value;
  return `${value('year')}-${value('month')}-${value('day')}`;
}

export function validateRequest(values, today = istanbulToday()) {
  if (!EVENT_TYPES.includes(values.eventType)) return 'Lütfen organizasyon türünü seçin.';
  const count = Number(values.guestCount);
  if (!Number.isInteger(count) || count < 1 || count > 100) return 'Kişi sayısı 1 ile 100 arasında olmalı.';
  if (values.date) {
    const parsed = new Date(`${values.date}T12:00:00Z`);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(values.date) || Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== values.date) return 'Lütfen geçerli bir tarih seçin.';
    if (values.date < today) return 'Lütfen bugünü veya gelecek bir tarihi seçin.';
  }
  if ((values.note || '').length > 500) return 'Notunuz en fazla 500 karakter olabilir.';
  return '';
}

export function whatsappUrl(values) {
  const date = values.date ? values.date.split('-').reverse().join('.') : 'Henüz belli değil';
  const lines = ['Merhaba, Ba&De için bilgi almak istiyorum.', `Organizasyon: ${values.eventType}`, `Tercih edilen tarih: ${date}`, `Kişi sayısı: ${Number(values.guestCount)}`];
  if (values.note?.trim()) lines.push(`Not: ${values.note.trim()}`);
  return `https://wa.me/905012486787?text=${encodeURIComponent(lines.join('\n'))}`;
}
