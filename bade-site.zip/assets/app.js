import { istanbulToday, validateRequest, whatsappUrl } from './contact.mjs';

const menuButton = document.querySelector('[data-menu-toggle]');
const menu = document.querySelector('#main-nav');
function closeMenu(restoreFocus=false) {
  menu?.classList.remove('is-open');
  menuButton?.setAttribute('aria-expanded', 'false');
  if (restoreFocus) menuButton?.focus();
}
menuButton?.addEventListener('click', () => {
  const open = menuButton.getAttribute('aria-expanded') !== 'true';
  menuButton.setAttribute('aria-expanded', String(open));
  menu.classList.toggle('is-open', open);
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && menu?.classList.contains('is-open')) {
    closeMenu(true);
  }
});
menu?.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
document.addEventListener('click', event => {
  if (menu?.classList.contains('is-open') && !event.target.closest('.site-header')) closeMenu();
});
matchMedia('(min-width: 1101px)').addEventListener('change', event => { if (event.matches) closeMenu(); });

const form = document.querySelector('[data-request-form]');
if (form) {
  const dateField = form.elements.date;
  dateField.min = istanbulToday();
  const requested = new URLSearchParams(location.search).get('hizmet');
  if (Array.from(form.elements.eventType.options).some(o => o.value === requested)) form.elements.eventType.value = requested;
  form.addEventListener('submit', event => {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(form));
    const error = validateRequest(values);
    const status = document.querySelector('[data-form-status]');
    status.textContent = error || 'Mesaj taslağınız hazır. Aşağıdaki bağlantıdan WhatsApp’ta açabilirsiniz.';
    status.classList.toggle('error', Boolean(error));
    const result = document.querySelector('[data-whatsapp-result]');
    result.hidden = Boolean(error);
    if (error) return;
    result.href = whatsappUrl(values);
    result.focus();
  });
  form.addEventListener('input', () => {
    document.querySelector('[data-whatsapp-result]').hidden = true;
    document.querySelector('[data-form-status]').textContent = '';
  });
}

const filterButtons = document.querySelectorAll('[data-gallery-filter]');
filterButtons.forEach(button => button.addEventListener('click', () => {
  filterButtons.forEach(b => b.setAttribute('aria-pressed', String(b === button)));
  let count = 0;
  document.querySelectorAll('[data-gallery-item]').forEach(item => {
    item.hidden = button.dataset.galleryFilter !== 'all' && !item.dataset.category.split(' ').includes(button.dataset.galleryFilter);
    if (!item.hidden) count++;
  });
  document.querySelector('[data-gallery-count]').textContent = `${count} fotoğraf gösteriliyor`;
}));

const lightbox = document.querySelector('#lightbox');
let lastImageTrigger;
document.querySelectorAll('[data-lightbox]').forEach(button => button.addEventListener('click', () => {
  lastImageTrigger = button;
  const original = button.querySelector('img');
  const image = lightbox.querySelector('img');
  image.src = button.dataset.lightbox;
  image.alt = original.alt;
  lightbox.querySelector('figcaption').textContent = button.dataset.caption;
  lightbox.showModal();
  document.body.classList.add('modal-open');
}));
lightbox?.querySelector('[data-close]')?.addEventListener('click', () => lightbox.close());
lightbox?.addEventListener('click', event => { if (event.target === lightbox) lightbox.close(); });
lightbox?.addEventListener('close', () => { document.body.classList.remove('modal-open'); lastImageTrigger?.focus(); });

const searchExamples = {
  nisan: { query: 'Çorlu nişan organizasyonu', title: 'Çorlu Nişan Organizasyonu | Ba&De', path: 'corlu-nisan-organizasyonu', description: 'Çorlu Çobançeşme’de 100 kişilik Ba&De davet salonunu ve nişan dekorlarını keşfedin. Tercih ettiğiniz tarih için WhatsApp üzerinden bilgi isteyin.', answer: 'Çorlu’da nişan mekânı araştırıyorsanız Ba&De Organizasyon ve Davet Salonu, Çobançeşme Mahallesi’nde yer alır. İşletmenin Instagram profilinde salon kapasitesi 100 kişi olarak belirtilir. Tarih ve organizasyon kapsamı için doğrudan işletmeyle görüşebilirsiniz.' },
  kina: { query: 'Çorlu kına gecesi', title: 'Çorlu Kına Gecesi | Ba&De', path: 'corlu-kina-gecesi', description: 'Ba&De’nin kırmızı kına konseptini inceleyin. Çorlu’daki 100 kişilik salon için tarih, konsept ve teklif bilgisi isteyin.', answer: 'Ba&De, Çorlu’da kına gecesi konseptini herkese açık Instagram paylaşımlarında gösteren bir davet salonudur. Kırmızı dekor örneklerini sitesinde inceleyebilir; seçtiğiniz tarih ve kişi sayısıyla işletmeden teklif isteyebilirsiniz.' },
  salon: { query: 'Çorlu 100 kişilik davet salonu', title: 'Çorlu 100 Kişilik Davet Salonu | Ba&De', path: 'corlu-davet-salonu', description: 'Çobançeşme Mahallesi, Pirsultan Caddesi’ndeki Ba&De davet salonunu tanıyın. 100 kişilik kapasite, gerçek mekân fotoğrafları ve ulaşım bilgileri.', answer: 'Ba&De Organizasyon ve Davet Salonu’nun Instagram profilinde kapasitesi 100 kişi olarak belirtilir. Adresi Çobançeşme Mahallesi, Pirsultan Caddesi No:3-5/A, Çorlu/Tekirdağ’dır. Ziyaret ve tarih uygunluğunu 0501 248 67 87 numarasından teyit edebilirsiniz.' }
};
document.querySelectorAll('[data-query]').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('[data-query]').forEach(b => b.setAttribute('aria-pressed', String(b === button)));
  const data = searchExamples[button.dataset.query];
  for (const field of ['query', 'title', 'description', 'answer']) document.querySelectorAll(`[data-preview-${field}]`).forEach(el => el.textContent = data[field]);
  document.querySelector('[data-preview-path]').textContent = data.path;
}));
document.querySelector('[data-print]')?.addEventListener('click', () => window.print());

